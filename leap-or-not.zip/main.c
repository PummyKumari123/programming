/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <conio.h>
int main()
{
    int num;
    printf("enter any no.\n");
    scanf("%d",&num);
    if(num%4==0)
    {
        printf("%d is leap year",num);
    }
        else
        {
        
    printf("%d is non leap year",num);
}
    return 0;
}
