/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <conio.h>
int main()
{
    int marks;
    scanf("%d",&marks);
    printf("grade obtained by student is %c");
    if(marks>=90)
    {
        printf("A+");
    }
    else if (marks>=80 && marks<90)
    {
        printf("A");
    }
    else if (marks>=70 && marks<80)
    {
        printf("B");
    }
    else if (marks>=60 && marks<70)
    {
        printf("C");
    }
    else if (marks<60)
    {
        
    printf("fail");
    }
    getch();
}
