/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <conio.h>
int main()
{
    int a,b,max;
    printf("enter two numbers");
    scanf("%d%d",&a,&b);
   (max=(a>b)? a:b);
    {
        printf("the maximum between  %d and %d is %d",a,b,max);
    }

    getch();
}

