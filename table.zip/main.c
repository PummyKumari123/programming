/*************************
 *
 *
 * 
 * **************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <conio.h>
int main()
{
    int num,i,table,n=1;
    printf("enter the number of which the table you want");
    scanf("%d",&num);
    for(i=1;i<=10;i++)
    {
       table=num*i;
       
    printf("%d\n",table);
    }

    getch();
}

