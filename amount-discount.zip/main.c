/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <conio.h>
void main()
{
    int amount;
    scanf("%d",&amount);
    printf("total amount is %d");
    if(amount>=10000)
    {
        amount=amount-2000; 
    printf("%d",amount);
    }
    else
    {
        printf("%d",amount);
    }

    getch();
}
