/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <conio.h>
int main()
{
    int i,num;
    scanf("%d",&num);
    while(i<=num){
    if(num==num/1,num%2==0) {
        printf("no. is not prime");
    }
    else
    {
        printf("no. is  prime no.");
    }
}
    return 0;
}


