/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <conio.h>
int main()
{
    int n,rem;
    printf("enter any no.");
    scanf("%d",&n);
    
 n=n/10;
 n/10==0;
 printf("%d\n",n);
    

    return 0;
}
